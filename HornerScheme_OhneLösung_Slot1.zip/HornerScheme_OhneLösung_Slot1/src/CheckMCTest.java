// Bitte nicht ändern. 'CheckMCTest' wird von anderen Klassen verwendet.
public class CheckMCTest {

    public static final String EXPECT =
            " 1. Welche der folgenden Aussagen treffen in Bezug auf Algorithmen und Datenstrukturen zu?\n" +
            "    \n" +
            "    XXXXXXXXX Bäume verwenden wir meist nur wo andere Datenstrukturen nicht passen.\n" +
            "    XXXXXXXXX Quicksort eignet sich besser für lineare Listen als für Arrays.\n" +
            "    XXXXXXXXX Bei unbekannter Datenverteilung gehen wir von Zufallsverteilung aus.\n" +
            "    XXXXXXXXX Ein AVL-Baum ist stets effizienter als ein einfacher Suchbaum.\n" +
            "    XXXXXXXXX Hash-Tabellen werden wegen ihrer Zufallsabhängigkeit kaum verwendet.\n" +
            "\n" +
            " 2. Welche der folgenden Aussagen treffen auf die notwendige Überprüfung von Eingabedaten zu?\n" +
            "    \n" +
            "    XXXXXXXXX Plausibilitätsprüfungen sollen direkt nach der Eingabe erfolgen.\n" +
            "    XXXXXXXXX Nicht validierbare Daten reparieren wir direkt nach der Eingabe.\n" +
            "    XXXXXXXXX Alle Daten von außerhalb des Programms müssen überprüft werden.\n" +
            "    XXXXXXXXX Java-Objekte vom Typ Pattern lesen nur überprüfte Daten ein.\n" +
            "    XXXXXXXXX Unzureichende Prüfung kann z.B. zu einer SQL-Injection führen.\n" +
            "\n" +
            " 3. Welche der folgenden Aussagen treffen auf Schleifen und Schleifeninvarianten zu?\n" +
            "    \n" +
            "    XXXXXXXXX Die Abbruchbedingung kann nicht Teil einer Schleifeninvariante sein.\n" +
            "    XXXXXXXXX Schleifeninvarianten müssen vor jedem Methodenaufruf erfüllt sein.\n" +
            "    XXXXXXXXX Die Schleifenbedingung ist Bestandteil jeder Schleifeninvariante.\n" +
            "    XXXXXXXXX Eine Schleifeninvariante beschreibt, was jede Iteration ändert.\n" +
            "    XXXXXXXXX Schleifeninvarianten müssen auch vor und nach der Schleife gelten.\n" +
            "\n" +
            " 4. Welche der folgenden Hoare-Tripel gelten (für Anweisungen in Java)?\n" +
            "    \n" +
            "    XXXXXXXXX {true} x = y<z ? y : z; {x>=y}\n" +
            "    XXXXXXXXX {x>2} if (x<0) x--; {x>2}\n" +
            "    XXXXXXXXX {x>0} while (x>0) x--; {x>0}\n" +
            "    XXXXXXXXX {true} x=0; {x>=0}\n" +
            "    XXXXXXXXX {x>2} if (x>0) x--; {x>2}\n" +
            "\n" +
            " 5. Welche der folgenden Aussagen treffen auf gut gewählte Kommentare in Programmen zu?\n" +
            "    \n" +
            "    XXXXXXXXX Besonders gute Programmstellen enthalten besonders viele Kommentare.\n" +
            "    XXXXXXXXX Kommentare legen auch fest, wer wofür verantwortlich ist.\n" +
            "    XXXXXXXXX Die meisten Kommentare beschreiben, wie Anweisungen zu lesen sind.\n" +
            "    XXXXXXXXX Invarianten sollen bei Deklarationen von Objektvariablen stehen.\n" +
            "    XXXXXXXXX In Methodenrümpfen stehen hauptsächlich Schleifeninvarianten.\n" +
            "\n";

    public static final long UID = 238498833605958L;

}
