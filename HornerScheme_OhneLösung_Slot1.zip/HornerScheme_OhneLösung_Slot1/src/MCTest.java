// Bitte beantworten Sie die Multiple-Choice-Fragen (maximal 25 Punkte, 1 Punkt pro 'Choice').

public class MCTest {

    // Wenn 'answer' in 'new Choice(...)' für davor stehende 'question' zutrifft, 'valid' bitte auf 'true' ändern.
    // Sonst 'valid' auf 'false' belassen (oder auf 'false' zurückändern).
    // Kommentare sind erlaubt, wirken sich aber nicht auf die Beurteilung aus.
    // Bitte sonst nichts ändern. Zur Kontrolle MCTest ausführen.
    public static void main(String[] args) {
        MCQuestion.checkAndPrint(

                new MCQuestion(
                        "Welche der folgenden Aussagen treffen in Bezug auf Algorithmen und Datenstrukturen zu?",

                        new Choice(false, "Bäume verwenden wir meist nur wo andere Datenstrukturen nicht passen."),
                        new Choice(false, "Quicksort eignet sich besser für lineare Listen als für Arrays."),
                        new Choice(false, "Bei unbekannter Datenverteilung gehen wir von Zufallsverteilung aus."),
                        new Choice(false, "Ein AVL-Baum ist stets effizienter als ein einfacher Suchbaum."),
                        new Choice(false, "Hash-Tabellen werden wegen ihrer Zufallsabhängigkeit kaum verwendet.")
                ),

                new MCQuestion(
                        "Welche der folgenden Aussagen treffen auf die notwendige Überprüfung von Eingabedaten zu?",

                        new Choice(false, "Plausibilitätsprüfungen sollen direkt nach der Eingabe erfolgen."),
                        new Choice(false, "Nicht validierbare Daten reparieren wir direkt nach der Eingabe."),
                        new Choice(false, "Alle Daten von außerhalb des Programms müssen überprüft werden."),
                        new Choice(false, "Java-Objekte vom Typ Pattern lesen nur überprüfte Daten ein."),
                        new Choice(false, "Unzureichende Prüfung kann z.B. zu einer SQL-Injection führen.")
                ),

                new MCQuestion(
                        "Welche der folgenden Aussagen treffen auf Schleifen und Schleifeninvarianten zu?",

                        new Choice(false, "Die Abbruchbedingung kann nicht Teil einer Schleifeninvariante sein."),
                        new Choice(false, "Schleifeninvarianten müssen vor jedem Methodenaufruf erfüllt sein."),
                        new Choice(false, "Die Schleifenbedingung ist Bestandteil jeder Schleifeninvariante."),
                        new Choice(false, "Eine Schleifeninvariante beschreibt, was jede Iteration ändert."),
                        new Choice(false, "Schleifeninvarianten müssen auch vor und nach der Schleife gelten.")
                ),

                new MCQuestion(
                        "Welche der folgenden Hoare-Tripel gelten (für Anweisungen in Java)?",

                        new Choice(false, "{true} x = y<z ? y : z; {x>=y}"),
                        new Choice(false, "{x>2} if (x<0) x--; {x>2}"),
                        new Choice(false, "{x>0} while (x>0) x--; {x>0}"),
                        new Choice(false, "{true} x=0; {x>=0}"),
                        new Choice(false, "{x>2} if (x>0) x--; {x>2}")
                ),

                new MCQuestion(
                        "Welche der folgenden Aussagen treffen auf gut gewählte Kommentare in Programmen zu?",

                        new Choice(false, "Besonders gute Programmstellen enthalten besonders viele Kommentare."),
                        new Choice(false, "Kommentare legen auch fest, wer wofür verantwortlich ist."),
                        new Choice(false, "Die meisten Kommentare beschreiben, wie Anweisungen zu lesen sind."),
                        new Choice(false, "Invarianten sollen bei Deklarationen von Objektvariablen stehen."),
                        new Choice(false, "In Methodenrümpfen stehen hauptsächlich Schleifeninvarianten.")
                )
        );
    }

    public static final long UID = 238498833605958L;

}
